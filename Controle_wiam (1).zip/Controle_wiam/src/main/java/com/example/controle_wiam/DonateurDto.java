package com.example.controle_wiam;

public interface DonateurDto {
    String getNom();
    String getEmail();
    String getTelephone();
}
