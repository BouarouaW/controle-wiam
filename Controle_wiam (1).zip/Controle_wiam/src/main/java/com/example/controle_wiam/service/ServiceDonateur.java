package com.example.controle_wiam.service;

import com.example.controle_wiam.Model.Donateur;
import com.example.controle_wiam.repository.DonateurRepository;
import com.example.controle_wiam.repository.SuiviDonateurRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class ServiceDonateur {
    private final DonateurRepository donateurRepository;
    private final SuiviDonateurRepository suiviDonateurRepository;

    public List<Donateur> findAll() { return donateurRepository.findAll(); }

    public Optional<Donateur> findById(Long id) {
        return donateurRepository.findById(id);
    }

    public Donateur create(Donateur d) {
        return donateurRepository.save(d);
    }

    public Donateur update(Long id, Donateur d) {
        Donateur old = donateurRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Not found"));
        old.setNom(d.getNom());
        old.setEmail(d.getEmail());
        old.setTelephone(d.getTelephone());
        old.setObjectifMontant(d.getObjectifMontant());
        old.setDateDebut(d.getDateDebut());
        old.setDateFin(d.getDateFin());
        return donateurRepository.save(old);
    }

    public void delete(Long id) {
        donateurRepository.deleteById(id);
    }

    public List<Donateur> getDonateursActifs() {
        return donateurRepository.findByDateFinAfter(LocalDate.now());
    }

    public Optional<Donateur> findByEmail(String email) {
        return donateurRepository.findByEmail(email);
    }

    public List<Object[]> getTopDonateurs() {
        return suiviDonateurRepository.findTopDonateurs();
    }
}
