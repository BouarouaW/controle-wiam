package com.example.controle_wiam.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SuiviDonateur {
    @Id @GeneratedValue
    private Long id;

    @ManyToOne
    private Donateur campagne;

    @NotBlank
    private String nomDonateur;

    @NotNull
    private Double montant;

    @NotNull
    private LocalDate date;
}
