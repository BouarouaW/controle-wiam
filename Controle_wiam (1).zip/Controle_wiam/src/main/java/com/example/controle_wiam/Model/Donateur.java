package com.example.controle_wiam.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Donateur {
    @Id @GeneratedValue
    private Long id;

    @NotBlank
    private String nom;

    @Email
    @NotBlank
    @Column(unique = true)
    private String email;

    @NotBlank
    private String telephone;

    @NotNull
    private Double objectifMontant;

    @NotNull
    private LocalDate dateDebut;

    @NotNull
    private LocalDate dateFin;
}

