package com.example.controle_wiam.controller;

import com.example.controle_wiam.Model.Donateur;
import com.example.controle_wiam.service.ServiceDonateur;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class DonateurController {

    private final ServiceDonateur service;



    @GetMapping("/api/donateurs/actifs")
    public List<Donateur> getActifs() {
        return service.getDonateursActifs();
    }

}
