package com.example.controle_wiam.repository;

import com.example.controle_wiam.Model.Donateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DonateurRepository extends JpaRepository<Donateur, Long> {
    List<Donateur> findByDateFinAfter(LocalDate date);
    Optional<Donateur> findByEmail(String email);
}

