package com.example.controle_wiam.repository;

import com.example.controle_wiam.Model.SuiviDonateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SuiviDonateurRepository extends JpaRepository<SuiviDonateur, Long> {
    @Query("SELECT s.campagne.nom, SUM(s.montant) FROM SuiviDonateur s GROUP BY s.campagne.nom ORDER BY SUM(s.montant) DESC")
    List<Object[]> findTopDonateurs();
}

