package com.example.controle_wiam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleWiamApplication {

    public static void main(String[] args) {
        SpringApplication.run(ControleWiamApplication.class, args);
    }

}
