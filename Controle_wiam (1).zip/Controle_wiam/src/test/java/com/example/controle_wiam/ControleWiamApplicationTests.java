package com.example.controle_wiam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleWiamApplicationTests {

    @Test
    void contextLoads() {
    }

}
